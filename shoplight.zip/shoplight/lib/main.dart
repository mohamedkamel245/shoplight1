import 'package:flutter/material.dart';

//my own imports
import 'package:shoplight/widgets/app.dart';


void main()=> runApp(App());
  


