// class BaseUrl{
// // static String login = "http://192.168.119.1/login/api/login.php/login/api/login.php";
// // static String register = "http://192.168.119.1/login/api/register.php";
//  static String lihaprodutc = "http://192.168.119.1/login/api/lihatProduk.php";
// // static String sliderservice ="http://192.168.119.1/login/api/sliders.php";
// // static const  String URL  = "http://192.168.119.1/login/api/";
// }