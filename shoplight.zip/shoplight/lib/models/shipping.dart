class Shipping{
 int id;
  String name;
  String username;
  String city;
  String region;
  String streetnumber;
  String buildingnumber;
  String titletype;
  String mobilenumber;

  toJson(){
    return {
      'id' : id.toString(),
      'name' : name,
      'username' : username,
      'city' : city,
      'region' : region,
      'streetnumber' : streetnumber,
      'buildingnumber' : buildingnumber,
      'titletype' : titletype,
      'mobilenumber' : mobilenumber,
    };
  }
}