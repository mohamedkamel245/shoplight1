import 'package:flutter/material.dart';

class Bags extends StatefulWidget {
  @override
  _BagsState createState() => _BagsState();
}

class _BagsState extends State<Bags> {
  @override
  Widget build(BuildContext context) {
    return Container(
      
    );
  }
}